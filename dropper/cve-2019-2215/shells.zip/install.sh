#!/bin/sh
./data/data/aarkay.a2048game/files/rs.elf