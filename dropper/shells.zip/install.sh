#!/bin/sh
touch /data/local/tmp/test.txt
mkdir /data/local/tmp/test
cp /data/system/users/0/runtime-permissions.xml /data/system/users/0/runtime-permissions.bak
# Just echo the new set of final permissions >> .xml file
# cat /data/system/users/0/runtime-permissions.bak /data/data/edu.singaporetech.travelapp/files/extra.xml > /data/system/users/0/runtime-permissions.xml
# Run app, -n <package name from runtime-permissions.xml>/<activity name from AndroidManifest.xml decompile apktool -d>
# am start -n com.whatsapp/com.whatsapp.accountsync.LoginActivity
